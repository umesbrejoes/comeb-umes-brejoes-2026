# COMEB 2026 — UMES BREJÕES

Portal do Conselho Municipal de Entidades de Base — COMEB 2026.

## Publicação no GitHub Pages
1. Crie um repositório público.
2. Envie todos os arquivos mantendo as pastas.
3. Vá em **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione `main` e `/ (root)`.
6. Salve.

## Atenção sobre os formulários
`inscricao.html` e `propostas.html` já possuem a interface, mas os envios estão em modo demonstrativo (`action="#"`). Antes de divulgar o link oficialmente, conecte os formulários a um serviço de recebimento/banco de dados adequado.

## Documentos
Os PDFs oficiais devem ser colocados em `documentos/` com estes nomes:
- `ata-comeb.pdf`
- `o-que-e-o-comeb.pdf`
- `regimento.pdf` (quando disponível)

O local e os horários do COMEB ainda devem ser atualizados quando definidos oficialmente.

## Arquivos novos da segunda etapa
- `admin.html`: painel restrito da organização.
- `backend-apps-script/Code.gs`: API/armazenamento via Google Sheets.
- `js/config.js`: URL pública da API (não contém segredo).
