# Backend do COMEB 2026 — Google Apps Script

Este backend recebe inscrições e propostas e grava os dados em uma planilha Google Sheets.

## Configuração
1. Crie uma planilha Google vazia.
2. Abra **Extensões → Apps Script**.
3. Apague o conteúdo padrão e cole `Code.gs`.
4. Salve.
5. Execute a função `setup()` uma vez e autorize.
6. Em **Implantar → Nova implantação → Aplicativo da Web**:
   - Executar como: você
   - Quem tem acesso: qualquer pessoa com o link
7. Copie a URL `/exec`.
8. No site, coloque essa URL em `js/config.js`.
9. Para o painel, use o token gerado em **Configurações do projeto → Propriedades do script**. Não publique esse token no GitHub.

## Segurança
O site público não recebe o token. O painel solicita o token no navegador. Não coloque o token em HTML/JS público nem no repositório.

## Dados
A planilha fica na conta Google usada para implantar o Apps Script. Revise as configurações de compartilhamento da planilha e limite o acesso à equipe responsável pelo COMEB.
