const CONFIG = {
  SHEET_NAME: 'Inscricoes',
  PROPOSALS_SHEET: 'Propostas',
  ADMIN_TOKEN_PROPERTY: 'COMEB_ADMIN_TOKEN'
};

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || 'health';
  if (action === 'health') return json_({ok:true, service:'COMEB 2026 API'});
  if (action === 'adminList') return adminList_(e);
  if (action === 'adminStats') return adminStats_(e);
  return json_({ok:false,error:'Ação não encontrada.'});
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (body.action === 'register') return register_(body);
    if (body.action === 'proposal') return proposal_(body);
    if (body.action === 'adminUpdate') return adminUpdate_(body);
    return json_({ok:false,error:'Ação não encontrada.'});
  } catch(err) {
    return json_({ok:false,error:String(err)});
  }
}

function setup() {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  getOrCreateSheet_(ss, CONFIG.SHEET_NAME, [
    'ID','Data/Hora','Nome','E-mail','WhatsApp','Instituição','Série/Curso','Município',
    'Possui Grêmio','Grêmio','Condição','GT','Observações','Status','Credenciado','Notas'
  ]);
  getOrCreateSheet_(ss, CONFIG.PROPOSALS_SHEET, [
    'ID','Data/Hora','Nome','Escola/Grêmio','GT','Problema','Proposta','Responsável','Próximos passos','Status'
  ]);
  if (!PropertiesService.getScriptProperties().getProperty(CONFIG.ADMIN_TOKEN_PROPERTY)) {
    PropertiesService.getScriptProperties().setProperty(CONFIG.ADMIN_TOKEN_PROPERTY, Utilities.getUuid());
  }
  return 'Estrutura criada. Copie o token de administrador das Propriedades do script e guarde-o em local seguro.';
}

function register_(b) {
  required_(b, ['nome','email','instituicao','municipio','possui_gremio','condicao']);
  const id = 'COMEB-' + Utilities.getUuid().slice(0,8).toUpperCase();
  const row = [
    id, new Date(), clean_(b.nome), clean_(b.email), clean_(b.telefone), clean_(b.instituicao),
    clean_(b.serie), clean_(b.municipio), clean_(b.possui_gremio), clean_(b.gremio),
    clean_(b.condicao), clean_(b.gt), clean_(b.observacoes), 'Pendente', 'Não', ''
  ];
  sheet_(CONFIG.SHEET_NAME).appendRow(row);
  return json_({ok:true,id:id,status:'Pendente'});
}

function proposal_(b) {
  required_(b, ['nome','entidade','gt','problema','proposta']);
  const id = 'PROP-' + Utilities.getUuid().slice(0,8).toUpperCase();
  sheet_(CONFIG.PROPOSALS_SHEET).appendRow([
    id,new Date(),clean_(b.nome),clean_(b.entidade),clean_(b.gt),clean_(b.problema),
    clean_(b.proposta),clean_(b.responsavel),clean_(b.passos),'Recebida'
  ]);
  return json_({ok:true,id:id});
}

function adminList_(e) {
  auth_(e.parameter.token);
  const sh = sheet_(CONFIG.SHEET_NAME);
  const values = sh.getDataRange().getDisplayValues();
  return json_({ok:true,headers:values.shift() || [],rows:values});
}

function adminStats_(e) {
  auth_(e.parameter.token);
  const sh = sheet_(CONFIG.SHEET_NAME);
  const rows = Math.max(0, sh.getLastRow()-1);
  const vals = rows ? sh.getRange(2,14,rows,3).getDisplayValues() : [];
  let pending=0, approved=0, rejected=0, checked=0;
  vals.forEach(r => {
    if (r[0]==='Pendente') pending++;
    if (r[0]==='Confirmada') approved++;
    if (r[0]==='Cancelada') rejected++;
    if (r[1]==='Sim') checked++;
  });
  return json_({ok:true,total:rows,pending,approved,rejected,checked});
}

function adminUpdate_(b) {
  auth_(b.token);
  if (!b.id || !b.status) throw new Error('ID e status são obrigatórios.');
  const sh = sheet_(CONFIG.SHEET_NAME);
  const data = sh.getDataRange().getValues();
  const idCol = 1;
  for (let i=1;i<data.length;i++) {
    if (String(data[i][idCol-1]) === String(b.id)) {
      sh.getRange(i+1,14).setValue(clean_(b.status));
      sh.getRange(i+1,15).setValue(b.credenciado ? 'Sim' : 'Não');
      sh.getRange(i+1,16).setValue(clean_(b.notas));
      return json_({ok:true});
    }
  }
  throw new Error('Inscrição não encontrada.');
}

function auth_(token) {
  const expected = PropertiesService.getScriptProperties().getProperty(CONFIG.ADMIN_TOKEN_PROPERTY);
  if (!expected || !token || token !== expected) throw new Error('Não autorizado.');
}

function sheet_(name) {
  const sh = SpreadsheetApp.getActiveSpreadsheet().getSheetByName(name);
  if (!sh) throw new Error('Execute setup() primeiro.');
  return sh;
}

function getOrCreateSheet_(ss,name,headers) {
  let sh=ss.getSheetByName(name);
  if (!sh) sh=ss.insertSheet(name);
  if (sh.getLastRow()===0) sh.appendRow(headers);
  sh.setFrozenRows(1);
  return sh;
}

function required_(b, keys) {
  keys.forEach(k => { if (!b[k] || !String(b[k]).trim()) throw new Error('Campo obrigatório: '+k); });
}

function clean_(v) {
  return String(v == null ? '' : v).trim().slice(0,5000);
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj))
    .setMimeType(ContentService.MimeType.JSON);
}
