function apiUrl(){return typeof COMEB_API_URL!=="undefined"?COMEB_API_URL:"";}
async function sendJson(action,payload){
  const url=apiUrl();
  if(!url) throw new Error("API ainda não configurada.");
  const res=await fetch(url,{method:"POST",headers:{"Content-Type":"text/plain;charset=utf-8"},body:JSON.stringify({action,...payload})});
  const data=await res.json(); if(!data.ok) throw new Error(data.error||"Não foi possível concluir."); return data;
}
document.addEventListener("DOMContentLoaded",()=>{
 const toggle=document.querySelector(".menu-toggle"),nav=document.querySelector(".nav-links");
 if(toggle&&nav)toggle.addEventListener("click",()=>nav.classList.toggle("open"));

 const reg=document.getElementById("registrationForm");
 if(reg)reg.addEventListener("submit",async e=>{
   e.preventDefault(); const msg=document.getElementById("formMessage"); msg.textContent="Enviando...";
   const data=Object.fromEntries(new FormData(reg).entries());
   try{const r=await sendJson("register",data); msg.textContent="Inscrição recebida. Seu protocolo é "+r.id+"."; reg.reset();}
   catch(err){msg.textContent=err.message==="API ainda não configurada."?"O sistema ainda não foi conectado ao formulário.":err.message;}
 });
 const prop=document.getElementById("proposalForm");
 if(prop)prop.addEventListener("submit",async e=>{
   e.preventDefault(); const msg=document.getElementById("proposalMessage"); msg.textContent="Enviando...";
   const data=Object.fromEntries(new FormData(prop).entries());
   try{const r=await sendJson("proposal",data); msg.textContent="Proposta recebida. Protocolo: "+r.id+"."; prop.reset();}
   catch(err){msg.textContent=err.message==="API ainda não configurada."?"O sistema ainda não foi conectado ao formulário.":err.message;}
 });
});
