// COLOQUE AQUI A URL /exec da implantação do Google Apps Script.
// Exemplo: const COMEB_API_URL = "https://script.google.com/macros/s/SEU_ID/exec";
const COMEB_API_URL = "";
